import qrcode

qr = qrcode.QRCode(
    version=10,
    box_size=8,
    border=5
)
data = 'https://www.youtube.com/'
qr.add_data(data)
qr.make(fit=True)  #make is function final qr code generate hoga
img = qr.make_image(fill= 'blue',back_color='white')
img.save('text.png')